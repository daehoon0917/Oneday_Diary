package com.example.calmemo;

public class DiaryActivity {
}
